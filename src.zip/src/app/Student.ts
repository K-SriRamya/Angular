export class Student{
    name:String;
    id:number;
    constructor(name:String,id:number){
        this.name=name;
        this.id=id;
    }
}